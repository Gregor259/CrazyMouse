import pygame
import random

pygame.init()
pygame.display.set_caption("Crazy Mouse")
screen_width = 800
screen_height = 600
screen = pygame.display.set_mode((screen_width, screen_height))

lovka_imag = [pygame.image.load('lovushka.png'), pygame.image.load('kot.png'), pygame.image.load('kzmey.png')]
lovka_options = [69, 438, 50, 450, 50, 445]

mous_imag = [pygame.image.load('mouse0.png'), pygame.image.load('mouse1.png'), pygame.image.load('mouse2.png'),
pygame.image.load('mouse3.png'), pygame.image.load('mouse4.png')]
img_chet = 5
pygame.mixer.music.load("fon.mp3")
false_sound = pygame.mixer.Sound("stolknovenie.mp3")
button_sound = pygame.mixer.Sound("cnopka.wav")

class Lovka:
    def __init__(self, x, y, width, image, speed):
        self.x = x
        self.y = y
        self.width = width
        self.image = image
        self.speed = speed

    def dvig(self):
        if self.x >= -self.width:
            screen.blit(self.image, (self.x, self.y))
            self.x -= self.speed
            return True
        else:
            return False

    def vyvod_self(self, rasst, y, width, image):
        self.x = rasst
        self.y = y
        self.width = width
        self.image = image
        screen.blit(self.image, (self.x, self.y))
class Button:
    def __init__(self, width, height):
        self.width = width
        self.height = height
        self.zvet1 = (0, 211, 0)
        self.zvet2 = (0, 240, 0)
        self.font_size = 50

    def draw(self, x, y, message, action=None):
        mouse = pygame.mouse.get_pos()
        click = pygame.mouse.get_pressed()
        if x < mouse[0] < x + self.width and y < mouse[1] < y + self.height:
            pygame.draw.rect(screen, self.zvet2, (x, y, self.width, self.height))
            if click[0] == 1:
                pygame.mixer.Sound.play(button_sound)
                pygame.time.delay(300)
                if action is not None:
                    if action == quit:
                        pygame.quit()
                        quit()
                    else:
                        action()
        else:
            pygame.draw.rect(screen, self.zvet1, (x, y, self.width, self.height))
        printing(message, x + 10, y + 10)

mouse_height = 100
mouse_width = 60
mouse_x = screen_width // 3
mouse_y = screen_height - mouse_height - 100
mouselovka_height = 70
mouselovka_width = 20
mouselovka_x = screen_width - 50
mouselovka_y = screen_height - mouselovka_height - 100
clock = pygame.time.Clock()
mouse_jump = False
jump_chet = 30
score = 0
vverh_mouselovka = False

def otcrytie_menu():
    menu_fon = pygame.image.load('Menu.jpg')
    startovaya_cnopka = Button(288, 70)
    vyhot_cnopka = Button(120, 70)
    pravila_cnopka = Button(120, 70)
    show = True
    while show:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()
        screen.blit(menu_fon, (0, 0))
        startovaya_cnopka.draw(260, 200, "START GAME", start_game)
        vyhot_cnopka.draw(350, 300, 'EXIT', quit)
        pravila_cnopka.draw(350, 400, "RULES", pravila)
        pygame.display.update()
        clock.tick(60)

def pravila():
    pravila_fon = pygame.image.load('pravila.jpg')
    startovaya_cnopka = Button(288, 70)

    show = True
    while show:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()
        screen.blit(pravila_fon, (0, 0))
        startovaya_cnopka.draw(260, 340, "START GAME", start_game)
        pygame.display.update()
        clock.tick(60)

def start_game():
    global score, mouse_jump, jump_chet, mouse_y
    while igravoy_cycle():
        score = 0
        mouse_jump = False
        jump_chet = 30
        mouse_y = screen_height - mouse_height - 100

def igravoy_cycle():
    global mouse_jump, mouse_x, mouse_y, mouselovka_width, mouselovka_height
    pygame.mixer.music.play(-1)
    game = True
    mouselovka_mas = []
    creating_mouselovka(mouselovka_mas)
    land = pygame.image.load('Land.jpg')
    while game:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()
        keys = pygame.key.get_pressed()
        if keys[pygame.K_SPACE]:
            mouse_jump = True
        if keys[pygame.K_ESCAPE]:
            stopping()
        if mouse_jump:
            jumping()
        count_scores(mouselovka_mas)

        screen.blit(land, (0, 0))
        printing("Score: " + str(score), 0, 10)

        drawing(mouselovka_mas)
        draw_mouse()
        if checking2(mouselovka_mas):
            pygame.mixer.music.stop()
            pygame.mixer.Sound.play(false_sound)
            game = False
        pygame.display.update()
        clock.tick(50)
    return ending()

def creating_mouselovka(array):
    vybor = random.randrange(0, 3)
    img = lovka_imag[vybor]
    width = lovka_options[vybor * 2]
    height = lovka_options[vybor * 2 + 1]
    array.append(Lovka(screen_width + 20, height, width, img, 4))
    vybor = random.randrange(0, 3)
    img = lovka_imag[vybor]
    width = lovka_options[vybor * 2]
    height = lovka_options[vybor * 2 + 1]
    array.append(Lovka(screen_width + 300, height, width, img, 4))
    vybor = random.randrange(0, 3)
    img = lovka_imag[vybor]
    width = lovka_options[vybor * 2]
    height = lovka_options[vybor * 2 + 1]
    array.append(Lovka(screen_width + 600, height, width, img, 4))

def jumping():
    global mouse_y, jump_chet, mouse_jump
    if jump_chet >= -30:
        if jump_chet == -10:
            pygame.mixer.Sound.play(false_sound)
        mouse_y -= jump_chet / 2.5
        jump_chet -= 1
    else:
        jump_chet = 30
        mouse_jump = False

def rasstf(massiv):
    maxis = max(massiv[0].x, massiv[1].x, massiv[2].x)
    if maxis < screen_width:
        rasst = screen_width
        if rasst - maxis < 50:
            rasst += 150
        else:
            rasst = maxis
        choice = random.randrange(0, 5)
        if choice == 0:
            rasst += random.randrange(200, 300)
        else:
            rasst += random.randrange(200, 350)
        return rasst

def drawing(massiv):
    for lovka in massiv:
        checking = lovka.dvig()
        if not checking:
            rasst = rasstf(massiv)
            vybor = random.randrange(0, 3)
            img = lovka_imag[vybor]
            width = lovka_options[vybor * 2]
            height = lovka_options[vybor * 2 + 1]
            lovka.vyvod_self(rasst, height, width, img)

def printing(message, x, y, shrift_color=(0, 0, 0), shrift_type='PingPong.ttf', shrift_size=30):
    shrift_type = pygame.font.Font(shrift_type, shrift_size)
    text = shrift_type.render(message, True, shrift_color)
    screen.blit(text, (x, y))

def draw_mouse():
    global img_chet
    if img_chet == 25:
        img_chet = 0
    screen.blit(mous_imag[img_chet // 5], (mouse_x, mouse_y + 21))
    img_chet += 1

def stopping():
    stopi = True
    pygame.mixer.music.pause()
    while stopi:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()
        printing  ('Paused. Press enter to continue', 160, 300)
        keys = pygame.key.get_pressed()
        if keys[pygame.K_RETURN]:
            stopi = False
        pygame.display.update()
        clock.tick(15)
    pygame.mixer.music.unpause()

def checking2(prepad):
    for i in prepad:
        if mouse_y + mouselovka_height >= i.y:
            if i.x <= mouse_x <= i.x + i.width:
                return True
            elif i.x <= mouse_x + mouse_width <= i.x + i.width:
                return True
    return False

def count_scores(prepad):
    global score, vverh_mouselovka
    if not vverh_mouselovka:
        for pr in prepad:
            if pr.x <= mouse_x + mouse_width / 2 <= pr.x + pr.width:
                if mouse_y + mouse_height - 5 <= pr.y:
                    vverh_mouselovka = True
                    break
    else:
        if jump_chet == -30:
            score += 1
            vverh_mouselovka = False

def ending():
    stopped = True
    while stopped:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()
        printing("GAME OVER",320, 210)
        printing("YOUR SCORE: " + str(score), 296, 250)
        keys = pygame.key.get_pressed()
        if keys[pygame.K_RETURN]:
            return True
        if keys[pygame.K_ESCAPE]:
            return False
        pygame.display.update()
        clock.tick(10)
otcrytie_menu()
pygame.quit()
quit()